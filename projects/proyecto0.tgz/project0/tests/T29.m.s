.section .rodata
.Lmicro_read_format:
	.string "%d"
.Lmicro_write_format:
	.string "%d\n"
.text
.globl main
.type main, @function
main:
	pushq %rbp
	movq %rsp, %rbp
	movl $0, %eax
	movl %eax, micro_var_K(%rip)
	movl micro_var_K(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl $0, %eax
	leave
	ret
.size main, .-main
.bss
.align 4
micro_var_K:
	.zero 4
.section .note.GNU-stack,"",@progbits
