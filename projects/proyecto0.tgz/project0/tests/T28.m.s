.section .rodata
.Lmicro_read_format:
	.string "%d"
.Lmicro_write_format:
	.string "%d\n"
.text
.globl main
.type main, @function
main:
	pushq %rbp
	movq %rsp, %rbp
	leaq micro_var_A(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	leaq micro_var_B(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	leaq micro_var_C(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	leaq micro_var_D(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	movl $11, %eax
	movl %eax, micro_var_K(%rip)
	movl micro_var_K(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl micro_var_A(%rip), %eax
	subl $9, %eax
	movl %eax, micro_tmp_1(%rip)
	movl micro_tmp_1(%rip), %eax
	movl %eax, micro_var_K(%rip)
	movl micro_var_K(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl $0, %eax
	leave
	ret
.size main, .-main
.bss
.align 4
micro_var_A:
	.zero 4
micro_var_B:
	.zero 4
micro_var_C:
	.zero 4
micro_var_D:
	.zero 4
micro_var_K:
	.zero 4
micro_tmp_1:
	.zero 4
.section .note.GNU-stack,"",@progbits
