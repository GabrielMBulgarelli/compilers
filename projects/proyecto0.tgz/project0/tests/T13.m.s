.section .rodata
.Lmicro_read_format:
	.string "%d"
.Lmicro_write_format:
	.string "%d\n"
.text
.globl main
.type main, @function
main:
	pushq %rbp
	movq %rsp, %rbp
	leaq micro_var_NOMBRE_MUY_LARGO_DE_VARIABLE(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	leaq micro_var_J(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	leaq micro_var_CONTADOR_LINEAS(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	leaq micro_var_OTRA_VARIABLE(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	leaq micro_var_FECHA(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	movl micro_var_NOMBRE_MUY_LARGO_DE_VARIABLE(%rip), %eax
	addl micro_var_J(%rip), %eax
	movl %eax, micro_tmp_1(%rip)
	movl micro_tmp_1(%rip), %eax
	movl %eax, micro_var_K(%rip)
	movl micro_var_K(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl micro_var_K(%rip), %eax
	addl micro_var_K(%rip), %eax
	movl %eax, micro_tmp_2(%rip)
	movl micro_tmp_2(%rip), %eax
	addl micro_var_NOMBRE_MUY_LARGO_DE_VARIABLE(%rip), %eax
	movl %eax, micro_tmp_3(%rip)
	movl micro_tmp_3(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl micro_var_OTRA_VARIABLE(%rip), %eax
	subl micro_var_K(%rip), %eax
	movl %eax, micro_tmp_4(%rip)
	movl micro_var_CONTADOR_LINEAS(%rip), %eax
	addl micro_tmp_4(%rip), %eax
	movl %eax, micro_tmp_5(%rip)
	movl micro_tmp_5(%rip), %eax
	addl micro_var_J(%rip), %eax
	movl %eax, micro_tmp_6(%rip)
	movl micro_tmp_6(%rip), %eax
	movl %eax, micro_var_CONTADOR_LINEAS(%rip)
	movl micro_var_CONTADOR_LINEAS(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	leaq micro_var_K(%rip), %rsi
	leaq .Lmicro_read_format(%rip), %rdi
	xorl %eax, %eax
	call scanf@PLT
	movl micro_var_K(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl micro_var_K(%rip), %eax
	addl micro_var_K(%rip), %eax
	movl %eax, micro_tmp_7(%rip)
	movl micro_tmp_7(%rip), %eax
	addl micro_var_K(%rip), %eax
	movl %eax, micro_tmp_8(%rip)
	movl micro_tmp_8(%rip), %eax
	addl micro_var_K(%rip), %eax
	movl %eax, micro_tmp_9(%rip)
	movl micro_tmp_9(%rip), %eax
	subl $22, %eax
	movl %eax, micro_tmp_10(%rip)
	movl micro_tmp_10(%rip), %eax
	addl micro_var_K(%rip), %eax
	movl %eax, micro_tmp_11(%rip)
	movl micro_tmp_11(%rip), %eax
	addl $7, %eax
	movl %eax, micro_tmp_12(%rip)
	movl micro_tmp_12(%rip), %eax
	subl micro_var_CONTADOR_LINEAS(%rip), %eax
	movl %eax, micro_tmp_13(%rip)
	movl micro_tmp_13(%rip), %eax
	movl %eax, micro_var_K(%rip)
	movl micro_var_OTRA_VARIABLE(%rip), %eax
	addl micro_var_FECHA(%rip), %eax
	movl %eax, micro_tmp_14(%rip)
	movl micro_tmp_14(%rip), %eax
	subl micro_var_NOMBRE_MUY_LARGO_DE_VARIABLE(%rip), %eax
	movl %eax, micro_tmp_15(%rip)
	movl micro_tmp_15(%rip), %eax
	movl %eax, micro_var_J(%rip)
	movl micro_var_CONTADOR_LINEAS(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl micro_var_OTRA_VARIABLE(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl micro_var_FECHA(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl micro_var_NOMBRE_MUY_LARGO_DE_VARIABLE(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl micro_var_J(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl micro_var_K(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl $0, %eax
	leave
	ret
.size main, .-main
.bss
.align 4
micro_var_NOMBRE_MUY_LARGO_DE_VARIABLE:
	.zero 4
micro_var_J:
	.zero 4
micro_var_CONTADOR_LINEAS:
	.zero 4
micro_var_OTRA_VARIABLE:
	.zero 4
micro_var_FECHA:
	.zero 4
micro_var_K:
	.zero 4
micro_tmp_1:
	.zero 4
micro_tmp_2:
	.zero 4
micro_tmp_3:
	.zero 4
micro_tmp_4:
	.zero 4
micro_tmp_5:
	.zero 4
micro_tmp_6:
	.zero 4
micro_tmp_7:
	.zero 4
micro_tmp_8:
	.zero 4
micro_tmp_9:
	.zero 4
micro_tmp_10:
	.zero 4
micro_tmp_11:
	.zero 4
micro_tmp_12:
	.zero 4
micro_tmp_13:
	.zero 4
micro_tmp_14:
	.zero 4
micro_tmp_15:
	.zero 4
.section .note.GNU-stack,"",@progbits
