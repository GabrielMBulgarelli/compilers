.section .rodata
.Lmicro_read_format:
	.string "%d"
.Lmicro_write_format:
	.string "%d\n"
.text
.globl main
.type main, @function
main:
	pushq %rbp
	movq %rsp, %rbp
	movl $0, %eax
	cmpl $0, %eax
	je .Lmicro_false_1
	movl $10, %eax
	movl %eax, micro_tmp_1(%rip)
	jmp .Lmicro_end_2
.Lmicro_false_1:
	movl $20, %eax
	movl %eax, micro_tmp_1(%rip)
.Lmicro_end_2:
	movl micro_tmp_1(%rip), %eax
	movl %eax, micro_var_K(%rip)
	movl micro_var_K(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl $1, %eax
	cmpl $0, %eax
	je .Lmicro_false_3
	movl $10, %eax
	movl %eax, micro_tmp_2(%rip)
	jmp .Lmicro_end_4
.Lmicro_false_3:
	movl $20, %eax
	movl %eax, micro_tmp_2(%rip)
.Lmicro_end_4:
	movl micro_tmp_2(%rip), %eax
	movl %eax, micro_var_K(%rip)
	movl micro_var_K(%rip), %esi
	leaq .Lmicro_write_format(%rip), %rdi
	xorl %eax, %eax
	call printf@PLT
	movl $0, %eax
	leave
	ret
.size main, .-main
.bss
.align 4
micro_var_K:
	.zero 4
micro_tmp_1:
	.zero 4
micro_tmp_2:
	.zero 4
.section .note.GNU-stack,"",@progbits
